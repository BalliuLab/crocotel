# TreeQTL = hierarchical error control for eQTL studies

# Function: get_n_tests_per_gene ----------------------------------------------
# Calls get_fam_sizes() with by_snp set to FALSE
get_n_tests_per_gene <- function(snp_map, gene_map, nearby = TRUE,
                                 dist = 1000000) {
  get_fam_sizes(snp_map, gene_map, by_snp = FALSE, nearby, dist)
}

# Function: get_n_tests_per_SNP ------------------------------------------------
# Calls get_fam_sizes() with by_snp set to TRUE
get_n_tests_per_SNP <- function(snp_map, gene_map, nearby = TRUE,
                                dist = 1000000) {
  get_fam_sizes(snp_map, gene_map, by_snp = TRUE, nearby, dist)
}

# Function: get_fam_sizes -----------------------------------------------------
# Computes the number of hypotheses in each family, where hypothesis families
# may be defined relative to either SNPs or probes/genes
#
# Args:
#   snp_map:     data frame with 3 columns: name, chromosome, and position.
#                This is the same format as the snpspos parameter for Matrix eQTL.
#   gene_map:    data frame with 4 columns: name, chromosome, and start and
#                end position. This is the same format as the genepos parameter
#                for Matrix eQTL.
#   by_snp:      are families defined by SNP? If FALSE, families will be defined
#                by probe/gene. Default is TRUE.
#   nearby:      TRUE if hypotheses of interest relate to SNP-gene pairs which
#                are nearby. FALSE if focus is distal regulation. Default value
#                is TRUE.
#   dist:        number of base pairs defining "nearby" region. Default is
#                1,000,000 = 1Mb.
# Return:
#   Data frame with the family name (either SNP or probe/gene) in the first
#   column and the number of tests in the family in the second column
get_fam_sizes <- function(snp_map, gene_map, by_snp = TRUE, nearby = TRUE,
                          dist = 1000000) {
  # Set column names for data frames with location information
  # Column 1 is family name i.e. either SNP or probe/gene id
  names(snp_map) <- c("family", "chr", "pos")
  names(gene_map) <- c("family", "chr", "s1", "s2")
  
  if (by_snp) {
    # For each SNP, find how many probes/genes are nearby using the definition
    # followed by Matrix eQTL that a SNP is within the given distance of the
    # closest end of the probe/gene
    fam_sizes <- data.table(snp_map, n_nearby = as.integer(0))
    setkey(fam_sizes, family)
    fam_sizes$n_total <- nrow(gene_map)
    
    # Iterate over chromosomes
    chrs <- unique(snp_map$chr)
    for (cur_chr in 1:length(chrs)) {
      cur_cur_gene_map <- gene_map[gene_map$chr == chrs[cur_chr], ]
      fam_sizes[chr == chrs[cur_chr], n_nearby := sum((cur_cur_gene_map$s2 > (pos - dist)) &
                                                        (cur_cur_gene_map$s1 < (pos + dist))),
                by = family]
    }
  } else {
    # For each probe, find how many SNPs are within given distance of closest end
    fam_sizes <- data.table(gene_map, n_nearby = as.integer(0))
    setkey(fam_sizes, family)
    fam_sizes$n_total <- nrow(snp_map)
    
    # Iterate over chromosomes
    chrs <- unique(gene_map$chr)
    for (cur_chr in 1:length(chrs)) {
      cur_cur_snp_map <- snp_map[snp_map$chr == chrs[cur_chr], ]
      fam_sizes[chr == chrs[cur_chr], n_nearby := sum((s2 > (cur_cur_snp_map$pos - dist)) &
                                                        (s1 < (cur_cur_snp_map$pos + dist))),
                by = family]
    }
  }
  
  if (nearby) {
    fam_sizes$n_tests <- fam_sizes$n_nearby
  } else {
    fam_sizes$n_tests <- fam_sizes$n_total - fam_sizes$n_nearby
  }
  
  as.data.frame(fam_sizes[ , c("family", "n_tests"), with = FALSE])
}

# Wrapper function: get_eGenes ------------------------------------------------
# Calls get_selected_families() with by_snp set to FALSE
get_eGenes <- function(n_tests_per_gene, m_eqtl_out, method = "BY",
                       level1 = 0.05, level2 = 0.05, slice_size = 1e+05,
                       silent = FALSE, gene_pvals = NA) {
  get_selected_families(n_tests_per_gene, m_eqtl_out, method, level1,
                        level2, by_snp = FALSE, slice_size, silent, gene_pvals)
}

# Wrapper function: get_eSNPs -------------------------------------------------
# Calls get_selected_families() with by_snp set to TRUE
get_eSNPs <- function(n_tests_per_SNP, m_eqtl_out, method = "BY",
                      level1 = 0.05, level2 = 0.05, slice_size = 1e+05,
                      silent = FALSE, snp_pvals = NA) {
  get_selected_families(n_tests_per_SNP, m_eqtl_out, method, level1,
                        level2, by_snp = TRUE, slice_size, silent, snp_pvals)
}

# Helper function: get_m_eqtl_cols --------------------------------------------
# Called in get_selected_families to get appropriate cols to read in from
# Matrix eQTL output based on header line, and in get_eAssociations
# to get format for all columns
get_m_eqtl_cols <- function(line1, by_snp, all = FALSE) {
  # Assumption is that there should either be 5 cols (SNP, gene, t-stat,
  # p-value, FDR OR SNP, gene, beta, t-stat, p-value) or 6 (SNP, gene,
  # beta, t-stat, p-value, FDR)
  
  if ((all || by_snp) && line1[1] != "SNP") {
    stop("Matrix eQTL output does not have expected column names: \n
         First column should be 'SNP'")
  }
  
  if ((all || !by_snp) && line1[2] != "gene" && line1[2] != "trait") { 
    stop("Matrix eQTL output does not have expected column names: \n
         Second column should be 'gene' or 'trait'")
  }
  
  if (length(line1) == 5) {
    if (all) {
      # Assume two character columns (for SNP and gene), then 3 numeric columns
      if (line1[4] == "p-value" || line1[4] == "p.value") {
        cols_to_read <- list(SNP = character(), gene = character(), t.stat = 0,
                             p.value = 0, FDR = 0)
      } else if (line1[5] == "p-value" || line1[5] == "p.value") {
        cols_to_read <- list(SNP = character(), gene = character(), beta = 0,
                             t.stat = 0, p.value = 0)
      } else {
        stop("Matrix eQTL output does not have expected column names")
      }
    } else {
      if (by_snp) {
        if (line1[4] == "p-value" || line1[4] == "p.value") {
          cols_to_read <- list(family = character(), NULL, NULL,
                               p.value = 0, NULL)
        } else if (line1[5] == "p-value" || line1[5] == "p.value") {
          cols_to_read <- list(family = character(), NULL, NULL,
                               NULL, p.value = 0)
        } else {
          stop("Matrix eQTL output does not have expected column names")
        }
      } else {  # if not by snp, then by gene
        if (line1[4] == "p-value" || line1[4] == "p.value") {
          cols_to_read <- list(NULL, family = character(), NULL,
                               p.value = 0, NULL)
        } else if (line1[5] == "p-value" || line1[5] == "p.value") {
          cols_to_read <- list(NULL, family = character(), NULL,
                               NULL, p.value = 0)
        } else {
          stop("Matrix eQTL output does not have expected column names")
        }
      }
    }
  } else if (length(line1) == 6) {
    if (all) {
      # Assume two character columns (for SNP and gene), then 4 numeric columns
      cols_to_read <- list(SNP = character(), gene = character(), beta = 0, t.stat = 0,
                           p.value = 0, FDR = 0)
    } else {
      if (by_snp) {
        if (line1[5] == "p-value" || line1[5] == "p.value") {
          cols_to_read <- list(family = character(), NULL, NULL, NULL,
                               p.value = 0, NULL)
        } else {
          stop("Matrix eQTL output does not have expected column names")
        }
      } else {
        if (line1[5] == "p-value" || line1[5] == "p.value") {
          cols_to_read <- list(NULL, family = character(), NULL, NULL,
                               p.value = 0, NULL)
        } else {
          stop("Matrix eQTL output does not have expected column names")
        }
      }
    }
  } else {
    stop("Matrix eQTL output does not have expected number of columns")
  }
  cols_to_read
}

# Main function: get_selected_families ----------------------------------------
# Generates a data frame listing all family discoveries (significant eSNPs or
# eGenes), the family p-value, and the number of discoveries within the family
#
# Args:
#   fam_sizes:   data frame with family name in first column and number of
#                tests in family in second column
#   m_eqtl_out:  txt file with Matrix eQTL output. Must follow Matrix eQTL
#                output file format and list associations in increasing order
#                of p-value.
#   method:      Method used for error control in family selection.
#                Either "BY" for Benjamini-Yekutieli, "BH" for Benjamini-Hochberg,
#                or "Bonf" for Bonferroni. Default is "BY".
#   level1:      target level for FDR or FWER for eSNPs or eGenes. Default
#                is 0.05.
#   level2:      target level for expected average proportion of false
#                eAssocation discoveries across selected families. Default is
#                0.05.
#   by_snp:      should hypothesis families be grouped by SNP? If FALSE, 
#                hypotheses will be grouped by probe/gene. Default is TRUE.
#   slice_size:  number of lines to read in at a time from Matrix eQTL output.
#                Default is 100,000.
#   silent:      Should function run in silent mode? If FALSE, progress updates
#                will be printed. Default is FALSE.
#   fam_pvals:   optional data frame providing family p-values if user prefers
#                a method other than Simes to obtain these
# Return:
#   Data frame with a column providing the family name, family p-value and number
#   of discoveries within the family for each selected family
get_selected_families <- function(fam_sizes, m_eqtl_out, method = "BY", level1 = 0.05,
                                  level2 = 0.05, by_snp = TRUE, slice_size = 1e+05,
                                  silent = FALSE, fam_pvals = NA) {
  # Create data table for number of tests for each family
  names(fam_sizes) <- c("family", "n_tests")
  fam_sizes <- data.table(fam_sizes)
  setkey(fam_sizes, family)
  
  # Create a data table for p-values for each family
  if (!is.na(fam_pvals)) {
    names(fam_pvals) <- c("family", "fam_p")
    family_table <- data.table(fam_pvals)
    setkey(fam_sizes, family)    
  } else {
    # If p-values are not provided, compute Simes p-value for each family
    # j is the number of ordered test statistics seen so far
    family_table <- data.table(data.frame(family = fam_sizes$family), j = 0,
                               fam_p = 1)
    setkey(family_table, family)
    
    # Read in Matrix eQTL output file in slices
    n_lines_done <- 0
    
    # Print stat if not in silent mode
    if (!silent) {
      print("Computing Simes p-values from Matrix eQTL output")
    }
    
    # Open connection to Matrix eQTL output file
    file_con <- file(m_eqtl_out, open = "r")
    
    # Read in header and get columns to read in
    line1 <- scan(file_con, what = "", nlines = 1, quiet = TRUE)
    cols_to_read <- get_m_eqtl_cols(line1, by_snp)
    
    # Read in Matrix eQTL output file in slices and process as read
    more_file <- TRUE
    while (more_file) {
      # Print progress update every after every 1,000,000 lines
      if (!silent & n_lines_done > 0 & n_lines_done %% 1000000 == 0) {
        print(paste("Lines done ", n_lines_done))
      }
      
      cur_slice <- scan(file_con, what = cols_to_read,
                        nmax = slice_size, multi.line = FALSE, quiet = TRUE)
      n_lines_read <- length(cur_slice$family)
      cur_slice <- data.frame(family = cur_slice$family,
                              p.value = cur_slice$p.value,
                              stringsAsFactors = FALSE)
      cur_slice <- data.table(cur_slice)
      setkey(cur_slice, family)
      
      # Keep track of whether we have hit the end of the file
      n_lines_done <- n_lines_done + n_lines_read
      if (n_lines_read < slice_size) {
        more_file <- FALSE
      }
      
      # Update number of tests so far and Simes p-value
      family_table[cur_slice, c("j", "fam_p") :=
                     list(j + .N, min(fam_p, p.value / (j + 1))), by = .EACHI]
    }
    
    # Close file connection
    close(file_con)
    
    # Multiply by total number of tests in family to get Simes p-value,
    # avoiding multiplication by 0 if family was empty
    family_table[fam_sizes, c("fam_p") := list(fam_p * max(n_tests, 1)), by = .EACHI]
  }
  
  # Total number of families
  n_fam <- nrow(family_table)
  
  # Get total number of rejections R across families
  if (method == "Bonf") {
    p_max <- level1 / n_fam
    R <- sum(family_table$fam_p <= p_max)
  } else {
    if (method == "BY") {
      threshold_across_fams <- level1 / sum(1 / seq(1:n_fam))
    } else {
      # Method = "BH"
      threshold_across_fams <- level1
    }
    
    family_pvals <- family_table$fam_p
    family_pvals[which(family_pvals > 1)] <- 1
    family_pvals <- sort(family_pvals)
    ind_reject <- which((family_pvals / (1:n_fam)) <= threshold_across_fams / n_fam)
    if (length(ind_reject) > 0) {
      p_max <- max(family_pvals[ind_reject])
    } else {
      p_max <- 0
    }
    R <- ifelse(length(ind_reject) > 0, max(ind_reject), 0)
  }
  
  # Control FDR within selected families to R * FDR threshold / # families
  q_fam <- R * level2 / n_fam
  
  # Table for selected families
  ind_sel <- which(family_table$fam_p <= p_max)
  sel_families <- family_table[ind_sel, ]
  
  # Get number of selections within each family as long as there are any selections
  if (nrow(sel_families) == 0) {
    if (!silent) {
      print("No families were selected")
    }
    sel_families$n_sel <- numeric()
  } else{
    # Print status if not in silent mode
    if (!silent) {
      print("Computing number of selections within each family")
    }
    
    # Number of selections and number of test statistics examined so far within
    # each family
    sel_families$n_sel <- 0
    sel_families$j_fam <- 0
    
    sel_families <- data.table(sel_families)
    setkey(sel_families, family)
    
    # Get number of tests
    sel_families[fam_sizes, c("n_tests") := list(n_tests), by = .EACHI]
    
    # Read in Matrix eQTL results in slices
    n_lines_done <- 0
    
    # Open connection to input file and read past header
    file_con <- file(m_eqtl_out, open = "r")
    line1 <- scan(file_con, what = "", nlines = 1, quiet = TRUE)
    cols_to_read <- get_m_eqtl_cols(line1, by_snp)
    
    # Largest p-value worth reading in
    p_max_to_read <- q_fam
    cur_max_p <- 0
    more_file <- TRUE
    while (cur_max_p < p_max_to_read && more_file) {
      # Print progress update every after every 100,000 lines
      if (!silent & n_lines_done > 0 & n_lines_done %% 1e+05 == 0) {
        print(paste("Lines done ", n_lines_done))
      }
      
      file_slice <- scan(file_con, what = cols_to_read,
                         nmax = slice_size, multi.line = FALSE, quiet = TRUE)
      n_lines_read <- length(file_slice$family)
      file_slice <- data.frame(family = file_slice$family,
                               p.value = file_slice$p.value,
                               stringsAsFactors = FALSE)
      n_lines_done <- n_lines_done + n_lines_read
      
      sel_families[file_slice, c("n_sel", "j_fam") :=
                     list(ifelse(((n_tests * p.value / (j_fam + 1)) <= q_fam) &
                                   (fam_p <= p_max), j_fam + 1, n_sel), j_fam + 1),
                   by = .EACHI]
      
      # Stop once we get into p-values larger than anything we could reject or
      # when there is no more input to read
      cur_max_p <- max(file_slice$p.value)
      if (n_lines_read < slice_size) {
        more_file <- FALSE
      }
    }
    
    # Close file connection
    close(file_con)
    
    # Warn if we hit end of file when we could have still rejected hypotheses
    # i.e. max p-value saved from Matrix eQTL could be too small
    if (!silent && cur_max_p < p_max_to_read && more_file == FALSE) {
      warning("Matrix eQTL output threshold may be too small for given levels")
    }
  }
  
  # Return data frame with family name, family p-value, and number of selections
  # within family for each selected family
  as.data.frame(sel_families[ , c("family", "fam_p", "n_sel"), with = FALSE],
                stringsAsFactors = FALSE)
}

# Function: get_eAssociations --------------------------------------------------
# Writes an output file with the full set of significant eAssociations.
# Columns are the same as those in Matrix eQTL output except that FDR
# is replaced by BBFDR (Benjamini-Bogomolov adjusted p-value)
#
# Args:
#   eDiscoveries: data frame with columns for eSNP or eGene name, p-value, and
#                 number of signficant associations. This data frame
#                 can be created by calling get_eSNPs() or get_eProbes()
#   n_tests:      data frame with SNP/gene name in first column and number of
#                 tests for the given SNP/gene in second column. This data frame
#                 can be created by calling get_n_tests_per_gene() or 
#                 get_n_tests_per_SNP(). May be set to NULL; in this case,
#                 the BBFDR is not computed.
#   m_eqtl_out:   txt file with Matrix eQTL output. Must follow Matrix eQTL
#                 output file format and list associations in increasing order
#                 of p-value.
#   out_file:     file name where eAssociations should be written
#   by_snp:       should hypothesis families be grouped by SNP? If FALSE, 
#                 hypotheses will be grouped by probe/gene. Default is TRUE.
#   slice_size:   number of lines to read in at a time from Matrix eQTL output.
#                 Default is 100,000.
#   silent:       Should function run in silent mode? If FALSE, progress updates
#                 will be printed. Default is FALSE.
get_eAssociations <- function(eDiscoveries, n_tests, m_eqtl_out, out_file, by_snp = TRUE,
                              slice_size = 1e5, silent = FALSE) {
  # Clean up any existing files with the given name
  unlink(out_file)
  
  # Rename cols
  names(eDiscoveries) <- c("family", "pval", "n_sel")
  eDiscoveries$family <- as.character(eDiscoveries$family)
  
  # Add column for n_tests if given
  if (!is.null(n_tests)) {
    names(n_tests) <- c("family", "n_tests")
    eDiscoveries <- merge(eDiscoveries, n_tests, by = "family", all.y = FALSE,
                          sort = FALSE)
    
    # Number of families
    n_fam <- nrow(n_tests)
  }
  eDiscoveries$n_remaining <- eDiscoveries$n_sel
  eDiscoveries <- data.table(eDiscoveries)
  setkey(eDiscoveries, family)
  
  # Number of families selected
  n_sel_fam <- nrow(eDiscoveries)

  # Read in Matrix eQTL results in slices
  n_lines_done <- 0
  
  # Number of eAssociations selected so far
  n_eAssoc <- 0
  
  # Total number of eAssociations expected
  tot_eAssoc <- sum(eDiscoveries$n_sel)
  
  # Open connection to input file and read past header
  file_con <- file(m_eqtl_out, open = "r")
  line1 <- scan(file_con, what = "", nlines = 1, quiet = TRUE)
  cols_to_read <- get_m_eqtl_cols(line1, by_snp, TRUE)
  
  # Print status if not in silent mode
  if (!silent) {
    print("Getting full list of eAssociations")
  }
  
  # Continue reading until we have the right number of associations or we hit the EOF
  more_file <- TRUE
  while (n_eAssoc < tot_eAssoc && more_file) {
    # Print progress update every after every 100,000 lines
    if (!silent & n_lines_done > 0 & n_lines_done %% 1e+05 == 0) {
      print(paste("Lines done ", n_lines_done))
    }
    
    file_slice <- data.frame(scan(file_con, what = cols_to_read,
                                  nmax = slice_size, multi.line = FALSE, quiet = TRUE),
                             stringsAsFactors = FALSE)
    n_lines_read <- length(file_slice$gene)
    n_lines_done <- n_lines_done + n_lines_read
    
    # Drop rows we are definitely not interested in
    if (by_snp) {
      good_rows <- which(file_slice$SNP %in% eDiscoveries$family)
    } else {
      good_rows <- which(file_slice$gene %in% eDiscoveries$family)
    }
    if (length(good_rows) > 0) {
      file_slice <- file_slice[good_rows, ]
      file_slice <- data.table(file_slice)
      
      # Select rows to keep
      if (by_snp) {
        cur_eAssoc_out <- file_slice[ , head(.SD[], eDiscoveries[SNP, n_remaining]), by = SNP]
        setkey(cur_eAssoc_out, SNP)
      } else {
        cur_eAssoc_out <- file_slice[ , head(.SD[], eDiscoveries[gene, n_remaining]), by = gene]
        setkey(cur_eAssoc_out, gene)
      }
      
      if (n_eAssoc == 0) {
        eAssoc_out <- cur_eAssoc_out
      } else {
        eAssoc_out <- rbind(eAssoc_out, cur_eAssoc_out)
      }
      
      # Update number of associations remaining to be found
      if (by_snp) {
        eAssoc_out_summary <- eAssoc_out[ , length(gene), by = SNP]
        names(eAssoc_out_summary) <- c("SNP", "n_found")
      } else {
        eAssoc_out_summary <- eAssoc_out[ , length(SNP), by = gene]
        names(eAssoc_out_summary) <- c("gene", "n_found")
      }
      eDiscoveries[eAssoc_out_summary, n_remaining := n_sel - n_found, by = .EACHI]
      
      # Update stopping criteria
      n_eAssoc <- nrow(eAssoc_out)
    }

    if (n_lines_read < slice_size) {
      more_file <- FALSE
    }
  }
  
  # Close file connection
  close(file_con)
  
  if (n_eAssoc > 0) {
    if (!is.null(n_tests)) {
      if (by_snp) {
        eAssoc_out[ , BBFDR := cummin(p.value[rev(order(p.value))] /
                                        (length(p.value):1L))[order(rev(order(p.value)))] *
                     eDiscoveries[SNP, n_tests] *
                     n_fam / n_sel_fam, by = SNP]             
      } else {
        eAssoc_out[ , BBFDR := cummin(p.value[rev(order(p.value))] /
                                        (length(p.value):1L))[order(rev(order(p.value)))] *
                     eDiscoveries[gene, n_tests] *
                     n_fam / n_sel_fam, by = gene]
      }
    }
    eAssoc_out$FDR <- NULL    
    
    write.table(eAssoc_out, out_file, quote = FALSE, row.names = FALSE)
    eAssoc_out
  } else {
    print("No eAssociations selected")
  }
}