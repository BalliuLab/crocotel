# Function: get_eGenes_multi_tissue -------------------------------------------
# Performs hierarchical selection for eGenes across multiple tissues.
# Returns a data frame with one row for each eGene selected in Level 1 of the
# hierarchy and an indicator of which tissues it was selected in.
# Full information on the selected SNP x gene associations in each tissue is
# written to disk in a separate file for each tissue.
#
# Args:
#   genes_by_tissue:  data frame with one row for each gene The first column
#                     should contain the gene name, then there should be one
#                     column for each tissue containing a binary indicator of
#                     whether the given gene was included in the eQTL analysis
#                     for the given tissue i.e. whether it passed QC in that
#                     tissue
#   snps_by_tissue:   data frame with one row for each snp. The first column
#                     should contain the snp name, then there should be one
#                     column for each tissue containing a binary indicator of
#                     whether the given SNP was included in the eQTL analysis
#                     for the given tissue i.e. whether it passed QC in that
#                     tissue
#   snp_map:          data frame with 3 columns: snp name, chromosome, and bp
#                     position
#   gene_map:         data frame with 4 columns: gene name, chromosome, start
#                     position and end position
#   nearby:           TRUE if hypotheses of interest relate to SNP-gene pairs
#                     which are nearby. FALSE if focus is distal regulation.
#                     Default value is TRUE
#   dist:             number of base pairs defining "nearby" region. Default is
#                     1,000,000 = 1Mb
#   m_eqtl_out_dir:   path to output files with eQTL output per tissue,
#                     thresholded to some reasonable level such as 0.01 or 0.05.
#                     These are assumed to follow the output format generated
#                     by Matrix eQTL i.e. with columns named SNP, gene, beta,
#                     t-stat, p-value, and FDR. The beta, t-stat, and FDR
#                     columns may contain dummy values if these are not of
#                     interest
#   tissue_names:     vector of names for each tissue in alphanumeric order
#   level1:           target error rate for Level 1 discoveries.
#                     Default is 0.05
#   level2:           target error rate for Level 2 discoveries.
#                     Default is 0.05
#   level3:           target error rate for Level 3 discoveries.
#                     Default is 0.05
# Return:
#   Data frame with one row for each selected eGene from the multi-tissue
#   analysis. First column = gene name, and subsequent columns contain
#   indicators of which tissues the gene was selected in. This function
#   also writes an output file per tissue with the full list of SNP x gene
#   associations and their corresponding p-valeus from the eQTL analysis output
#   file for the given tissue.
get_eGenes_multi_tissue <- function(genes_by_tissue, snps_by_tissue,
                                    snp_map, gene_map, nearby = TRUE,
                                    dist = 1e+06,
                                    m_eqtl_out_dir, tissue_names,
                                    level1 = 0.05, level2 = 0.05,
                                    level3 = 0.05) {
  # Assign standard names to columns with snp and gene names
  names(snp_map)[1] <- "snp"
  names(gene_map)[1] <- "gene"
  names(snps_by_tissue)[1] <- "snp"
  names(genes_by_tissue)[1] <- "gene"
  
  # Step 0.1. Compute gene-level Simes p-values for each gene in each tissue
  print(paste("Step 0.1: Computing summary statistics for each tissue"))
  
  # List output files from tissue-by-tissue association analysis
  m_eqtl_outfiles <- list.files(m_eqtl_out_dir, full.names = TRUE)
  n_tissue <- length(tissue_names)
  
  # Iterate over output files i.e. tissues
  for (i in 1:n_tissue) {
    cur_tissue_name <- tissue_names[i]
    print(paste("Computing summary statistics for tissue ", cur_tissue_name,
                sep = ""))
    
    # Get names of SNPs and genes that passed QC (i.e. were used as input to
    # eQTL analysis) in current tissue
    snps_this_tissue <- snps_by_tissue$snp[which(
      snps_by_tissue[ , i + 1] == 1)]
    genes_this_tissue <- genes_by_tissue$gene[which(
      genes_by_tissue[ , i + 1]== 1)]
    
    # Compute number of SNPs tested per gene in each tissue
    n_SNPs_per_gene_this_tissue <- get_n_tests_per_gene(
      snp_map[which(snp_map$snp %in% snps_this_tissue), ],
      gene_map[which(gene_map$gene %in% genes_this_tissue), ],
      nearby = nearby,
      dist = dist)
    
    # Drop genes with 0 SNPs in cis region
    n_SNPs_per_gene_this_tissue <- n_SNPs_per_gene_this_tissue[
      n_SNPs_per_gene_this_tissue$n_tests > 0, ]
    
    # Use get_eGenes function from core.R to get gene-level Simes
    # p-values for each gene in the current tissue
    # Set level1 and level2 to 1 since we don't want to do selection
    gene_simes_cur_tissue <- get_eGenes(n_SNPs_per_gene_this_tissue,
                                        m_eqtl_outfiles[i],
                                        method = "BH", level1 = 1,
                                        level2 = 1, silent = TRUE)
    
    # If no p-val listed, assume it is 1 (i.e. a conservative large guess
    # given that SNP gene association p-values were large enough to be above
    # threshold for saved output)
    gene_simes_cur_tissue <- merge(gene_simes_cur_tissue,
                                   n_SNPs_per_gene_this_tissue,
                                   by = "family",
                                   all = TRUE)
    gene_simes_cur_tissue$fam_p[which(is.na(gene_simes_cur_tissue$fam_p))] <- 1
    
    if (i == 1) {
      eGene_pvals <- gene_simes_cur_tissue[ , c("family", "fam_p")]
      n_SNPs_per_gene_xT <- n_SNPs_per_gene_this_tissue
    } else {
      eGene_pvals <- merge(eGene_pvals,
                           gene_simes_cur_tissue[ , c("family", "fam_p")],
                           by = "family", all = TRUE)
      n_SNPs_per_gene_xT <- merge(n_SNPs_per_gene_xT,
                                  n_SNPs_per_gene_this_tissue,
                                  by = "family", all = TRUE)
    }
    names(eGene_pvals)[i + 1] <- cur_tissue_name
    names(n_SNPs_per_gene_xT)[i + 1] <- cur_tissue_name 
  }
  names(eGene_pvals)[1] <- "gene"
  
  # Clean up loop vars
  remove(cur_tissue_name, n_SNPs_per_gene_this_tissue, gene_simes_cur_tissue,
         snps_this_tissue, genes_this_tissue)
  
  # Step 0.2 Compute combined p-value across tissues --------------------------
  print("Step 0.2: Computing summary statistics across tissues")
  
  # Indices for columns containing p-values
  col_ind_pvals <- 2:(n_tissue + 1)
  
  # Apply to table (omitting first col with gene name)
  eGene_pvals$simes_p <- apply(eGene_pvals[ , col_ind_pvals], 1, get_simes_p) 
  
  # Step 1: select eGenes across tissues using BH -----------------------------
  print("Step 1: Selecting eGenes across tissues")
  
  # Q-value based selection: select eGenes by controlling FDR to level level1
  eGene_xT_qvals <- qvalue(eGene_pvals$simes_p, lambda = 0)$qvalue
  # i.e. cross-tissue = xT
  
  # How many pass threshold?
  R_G <- sum(eGene_xT_qvals <= level1)
  
  print(paste("Number of cross-tissue eGenes = ", R_G))
  
  # Step 2: select tissues for selected genes using BB ------------------------
  # Control FDR across tissues for selected genes to R * FDR threshold / # genes
  print("Step 2: Selecting tissues in which eGenes are active")
  q2_adj <- R_G * level2 / nrow(eGene_pvals)
  
  # Get rejections within for each selected gene
  ind_sel_simes <- which(eGene_xT_qvals <= level1)
  sel_eGenes_simes <- eGene_pvals[ind_sel_simes, ]
  
  rej_simes <- t(1 * apply(sel_eGenes_simes[ , c(col_ind_pvals)], 1,
                           qsel_by_fam, q2_adj))
  
  # Step 3: select SNPs for selected gene x tissue pairs ----------------------
  print("Step 3: Selecting SNPs associated to each gene in each tissue")
  # This requires collecting the SNP p-values for the given gene x tissue
  # combinations
  
  # Get number of tissues tested and number selected for each selected gene
  sel_eGenes_simes$n_sel_tissues <- rowSums(rej_simes)
  sel_eGenes_simes$n_tested_tissues <- rowSums(!is.na(
    sel_eGenes_simes[ ,col_ind_pvals]))
  
  m_eqtl_out_files <- list.files(m_eqtl_out_dir)
  for (i in 1:n_tissue) {
    cur_tissue_name <- tissue_names[i]
    print(paste("Selecting SNPs for tissue", cur_tissue_name))
    
    # Table for selected genes
    sel_gene_names_this_tissue <- sel_eGenes_simes$gene[
      which(rej_simes[ , i] == 1)]
    sel_gene_info <- n_SNPs_per_gene_xT[
      which(n_SNPs_per_gene_xT$family %in% sel_gene_names_this_tissue),
      c(1, i + 1)]
    names(sel_gene_info)[2] <- "n_tests"
    
    # Get number of tissues selected for each gene and # of tissues tested
    sel_gene_info <- merge(sel_gene_info,
                           sel_eGenes_simes[ , c("gene", "n_sel_tissues",
                                                 "n_tested_tissues")],
                           by.x = "family", by.y = "gene",
                           all.x = TRUE, all.y = FALSE)
    
    n_sel_per_gene <- get_nsel_SNPs_per_gene_tissue_pair(sel_gene_info,
                                                         cur_tissue_name,
                                                         m_eqtl_outfiles[i],
                                                         R_G,
                                                         nrow(eGene_pvals),
                                                         level3 = level3)
    print(paste("Total number of associations for tissue", cur_tissue_name, 
                "=", sum(n_sel_per_gene$n_sel_snp)))
    
    out_file_name <- paste("eAssoc_3level_by_gene_tissue_", cur_tissue_name,
                           ".txt", sep = "")
    print(paste("Writing output file", out_file_name))
    get_eAssociations(data.frame(family = n_sel_per_gene$family, pval = NA,
                                 n_sel = n_sel_per_gene$n_sel_snp),
                      NULL, m_eqtl_outfiles[i],
                      out_file_name, by_snp = FALSE, silent = TRUE)
  }
  
  # Prepare return value
  eGene_xT_sel <- data.frame(gene = sel_eGenes_simes$gene)
  eGene_xT_sel <- cbind(eGene_xT_sel, rej_simes)
  names(eGene_xT_sel)[2:(n_tissue + 1)] <- tissue_names
  eGene_xT_sel
}


# Function: get_simes_p -------------------------------------------------------
# Internal helper function to compute Simes p-value
#
# Args:
#   pvals: vector of p-values (which may include NAs)
# Returns:
#   Simes p-value, omitting NA input values i.e. assuming that these do not count
#   toward the total number of tests
get_simes_p <- function(pvals) {
  # Don't include NAs
  pvals <- pvals[!is.na(pvals)]
  
  if (length(pvals) > 0) {
    pvals <- sort(as.numeric(pvals))
    length(pvals) * min(pvals / seq(1:length(pvals)))
  } else {
    # Return NA if all input p-values were NA
    NA
  }
}


# Function: qsel_by_fam -------------------------------------------------------
# Interal helper function that returns a binary indicator vector of whether there
# is an assocation using BH method given target level. Here "fam" refers to
# "family" i.e. a set of related hypotheses
#
# Args:
#   pvals: vector of p-vals (which may include NAs)
#   q:     target level for BH method
# Returns:
#   vector of binary indicators of which each p-value passed cut-off for selection
qsel_by_fam <- function(pvals, q) {
  is_sel <- rep(NA, length(pvals))
  is_sel[which(is.na(pvals))] <- FALSE
  if (sum(!is.na(pvals)) > 1) {
    is_sel[which(is.na(is_sel))] <- qvalue(pvals[which(is.na(is_sel))],
                                           lambda = 0,
                                           fdr.level = q)$significant
  } else {
    is_sel[which(is.na(is_sel))] <- pvals[which(!is.na(pvals))] <= q
  }
  is_sel
}


# Function: get_nsel_SNPs_per_gene_tissue_pair -------------------------------
# Generates a data frame listing the number of selected SNPs for the given
# tissue/eGene combination
#
# Args:
#   n_tests_per_gene:   data frame with gene name in first column and number of
#                       tests in second column (i.e. number of SNPs in cis region
#                       where both the SNP and gene passed QC in this tissue)
#   sel_genes:          list of genes selected in this tissue
#   tissue_name:
#   m_eqtl_out:         txt file with Matrix eQTL output. Must follow Matrix
#                       eQTL output file format and list associations in
#                       increasing order of p-value.
#   level3:             target level for expected average proportion of false
#                       eAssocation discoveries across selected families. Default is
#                       0.05.
#   slice_size:         number of lines to read in at a time from Matrix eQTL output.
#                       Default is 100,000.
#   silent:             Should function run in silent mode? If FALSE, progress updates
#                       will be printed. Default is FALSE.
# Return:
#   Data frame with a column providing the gene name and number
#   of SNP discoveries for the given gene in the current tissue
get_nsel_SNPs_per_gene_tissue_pair <- function(sel_genes, 
                                               tissue_name,
                                               m_eqtl_out,
                                               R_G,
                                               M,
                                               level3 = 0.05,
                                               slice_size = 1e+05,
                                               silent = FALSE) {
  # Convert data frame to data table
  sel_genes <- data.table(sel_genes)
  setkey(sel_genes, family)
  
  # Compute target FDR level across SNPs for the current gene x tissue pair
  sel_genes$q_adj <- R_G * sel_genes$n_sel_tissues * level3 / M /
    sel_genes$n_tested_tissues
  
  # Get number of selections for each gene
  # Print status if not in silent mode
  if (!silent) {
    print("Computing number of selections for each gene x tissue selection")
  }
  
  # Number of selections and number of test statistics examined so far for
  # each gene
  sel_genes$n_sel_snp <- 0
  sel_genes$j_snp <- 0
  
  # Read in Matrix eQTL results in slices
  n_lines_done <- 0
  
  # Open connection to input file and read past header
  file_con <- file(m_eqtl_out, open = "r")
  line1 <- scan(file_con, what = "", nlines = 1, quiet = TRUE)
  cols_to_read <- get_m_eqtl_cols(line1, by_snp = FALSE)
  
  # Largest p-value worth reading in
  p_max_to_read <- max(sel_genes$q_adj)
  cur_max_p <- 0
  more_file <- TRUE
  while (cur_max_p < p_max_to_read && more_file) {
    # Print progress update every after every 100,000 lines
    if (!silent & n_lines_done > 0 & n_lines_done %% 1e+05 == 0) {
      print(paste("Lines done ", n_lines_done))
    }
    
    file_slice <- scan(file_con, what = cols_to_read,
                       nmax = slice_size, multi.line = FALSE, quiet = TRUE)
    n_lines_read <- length(file_slice$family)
    file_slice <- data.frame(family = file_slice$family,
                             p.value = file_slice$p.value,
                             stringsAsFactors = FALSE)
    n_lines_done <- n_lines_done + n_lines_read
    
    sel_genes[file_slice, c("n_sel_snp", "j_snp") :=
                list(ifelse(((n_tests * p.value / (j_snp + 1)) <= q_adj),
                            j_snp + 1, n_sel_snp), j_snp + 1),
              by = .EACHI]
    
    # Stop once we get into p-values larger than anything we could reject or
    # when there is no more input to read
    cur_max_p <- max(file_slice$p.value)
    if (n_lines_read < slice_size) {
      more_file <- FALSE
    }
  }
  
  # Close file connection
  close(file_con)
  
  # Warn if we hit end of file when we could have still rejected hypotheses
  # i.e. max p-value saved from Matrix eQTL could be too small
  if (cur_max_p < p_max_to_read && more_file == FALSE) {
    warning("Matrix eQTL output threshold may be too small for given levels")
  }
  
  # Return data frame with family name, family p-value, and number of selections
  # within family for each selected family
  as.data.frame(sel_genes[ , c("family", "n_tests", "n_sel_snp"),
                          with = FALSE], stringsAsFactors = FALSE)
}


# Function: get_n_tests_per_SNP_multi_tissue ----------------------------------
# Returns a data frame with the SNP name in the first column and the number genes
# which were tested for association with the SNP in any tissue.
# Note that this function only works for up to 62 tissues as currently written.
# Note as well that if the definition of trans being used is that the SNP and gene
# are on different chromosomes, this can be accomodated by setting nearby = FALSE
# and dist = Inf.
#
# Args:
#  snp_map_xT:   data frame with 3 initial columns (name, chrom, and position) that
#                match standard SNP map file, followed by 1 column for each tissue
#                with a 0/1 indicator of whether the given SNP passed QC in that tissue.
#                xT = across tissues
#  gene_map_xT:  data frame with 4 initial columns (name, chrom, and start and end
#                position) that match standard gene map file, followed by 1 column
#                for each tissue with a 0/1 indicator of whether the given gene passed
#                QC in that tissue
#                xT = across tissues
#  nearby:       TRUE if hypotheses of interest relate to SNP-gene pairs which
#                are nearby. FALSE if focus is distal regulation. Default value
#                is TRUE
#  dist:         number of base pairs defining "nearby" region. Default is
#                1,000,000 = 1Mb
# Return:
#   Data frame with the SNP name in the first column and the number genes
#   which were tested for association with the SNP in any tissue
get_n_tests_per_SNP_multi_tissue <- function(snp_map_xT, gene_map_xT, nearby = TRUE,
                                             dist = 1000000) {
  # Set column names for data frames with location information
  # Column 1 is "family" i.e. either SNP or probe/gene id
  # where family refers to the group of related hypotheses
  names(snp_map_xT)[1:3] <- c("family", "chr", "pos")
  names(gene_map_xT)[1:4] <- c("family", "chr", "s1", "s2")
  
  # Number of tissues
  n_tissues <- ncol(snp_map_xT) - 3
  
  # Raw tissue columns are the columns with 0/1 for whether snp/gene
  # was found in given tissue following the initial location columns
  raw_snp_cols <- 4:ncol(snp_map_xT)
  raw_gene_cols <- 5:ncol(gene_map_xT)
  
  # Create summary columns of integers with bitwise condensed version of
  # binary information from each tissue
  # Signed 32 bit integer => max 31 bits, so current code (which constructs
  # two such columns) can accommodate at most 62 tissues
  bit_max <- 31
  
  # If number of tissues is less than 32, compute 1 summary integer, and set second to 0
  if (n_tissues <= bit_max) {
    snp_map_xT$xT_summary1 <- rowSums(snp_map_xT[ , raw_snp_cols[1:n_tissues]] *
                                        as.numeric(matrix(2^(1:n_tissues - 1),
                                                          ncol = n_tissues,
                                                          nrow = nrow(snp_map_xT),
                                                          byrow = TRUE)))
    gene_map_xT$xT_summary1 <- rowSums(gene_map_xT[ , raw_gene_cols[1:n_tissues]] *
                                         as.numeric(matrix(2^(1:n_tissues - 1),
                                                           ncol = n_tissues,
                                                           nrow = nrow(gene_map_xT),
                                                           byrow = TRUE)))
    snp_map_xT$xT_summary2 <- 0
    gene_map_xT$xT_summary2 <- 0
  } else {
    snp_map_xT$xT_summary1 <- rowSums(snp_map_xT[ , raw_snp_cols[1:bit_max]] *
                                        as.numeric(matrix(2^(1:bit_max - 1),
                                                          ncol = bit_max,
                                                          nrow = nrow(snp_map_xT),
                                                          byrow = TRUE)))
    gene_map_xT$xT_summary1 <- rowSums(gene_map_xT[ , raw_gene_cols[1:bit_max]] *
                                         as.numeric(matrix(2^(1:bit_max - 1),
                                                           ncol = bit_max,
                                                           nrow = nrow(gene_map_xT),
                                                           byrow = TRUE)))
    snp_map_xT$xT_summary2 <- rowSums(snp_map_xT[ , raw_snp_cols[(bit_max + 1):
                                                                   n_tissues]] *
                                        as.numeric(matrix(2^(1:(n_tissues - bit_max) - 1),
                                                          ncol = n_tissues - bit_max,
                                                          nrow = nrow(snp_map_xT),
                                                          byrow = TRUE)))
    gene_map_xT$xT_summary2 <- rowSums(gene_map_xT[ , raw_gene_cols[(bit_max + 1):
                                                                      n_tissues]] *
                                         as.numeric(matrix(2^(1:(n_tissues - bit_max) - 1),
                                                           ncol = n_tissues - bit_max,
                                                           nrow = nrow(gene_map_xT),
                                                           byrow = TRUE)))
  }
  
  # Drop original set of raw 0/1 binary data columns
  snp_map_xT <- snp_map_xT[ , -raw_snp_cols]
  gene_map_xT <- gene_map_xT[ , -raw_gene_cols]
  
  # For each SNP, find how many probes/genes are nearby using the definition
  # followed by Matrix eQTL that a SNP is within the given distance of the
  # closest end of the probe/gene
  fam_sizes <- data.table(snp_map_xT, n_nearby = as.integer(0))
  setkey(fam_sizes, family)
  fam_sizes$n_total <- nrow(gene_map_xT)
  
  # Iterate over chromosomes
  chrs <- unique(snp_map_xT$chr)
  for (cur_chr in 1:length(chrs)) {
    cur_chr_gene_map <- gene_map_xT[gene_map_xT$chr == chrs[cur_chr], ]
    # Number of nearby genes = number of genes nearby given SNP and gene
    # locations where SNP and gene pass QC in at least one of the same tissues
    fam_sizes[chr == chrs[cur_chr], n_nearby :=
                sum((cur_chr_gene_map$s2 > (pos - dist)) &
                      (cur_chr_gene_map$s1 < (pos + dist)) &
                      (bitwAnd(cur_chr_gene_map$xT_summary1, xT_summary1) |
                         bitwAnd(cur_chr_gene_map$xT_summary2, xT_summary2))),
              by = family]
  }
  
  if (nearby) {
    fam_sizes$n_tests <- fam_sizes$n_nearby
  } else {
    fam_sizes$n_tests <- fam_sizes$n_total - fam_sizes$n_nearby
  }
  
  as.data.frame(fam_sizes[ , c("family", "n_tests"), with = FALSE])
}


# Function: get_eSNPs_multi_tissue --------------------------------------------
# Performs hierarchical selection for eSNPs across multiple tissues.
# Returns a data frame with one row for each selected SNP-gene pair, where the
# first column contains the SNP name, the second column contains the gene name,
# and subsequent columns (one for each tissue) contain a nonzero entry giving
# the p-value for the significant associations in each tissue or a 0 to indicate
# that the association in the given tissue was not significant. Note that input
# p-values should be strictly greater than 0.
#
#   genes_by_tissue:  data frame with one row for each gene The first column
#                     should contain the gene name, then there should be one
#                     column for each tissue containing a binary indicator of
#                     whether the given gene was included in the eQTL analysis
#                     for the given tissue i.e. whether it passed QC in that
#                     tissue
#   snps_by_tissue:   data frame with one row for each snp. The first column
#                     should contain the snp name, then there should be one
#                     column for each tissue containing a binary indicator of
#                     whether the given SNP was included in the eQTL analysis
#                     for the given tissue i.e. whether it passed QC in that
#                     tissue
#   n_tests_per_SNP:  data frame with SNP name in first column and number 
#                     of genes tested for association to the given SNP (which depends
#                     on whether cis or trans analysis is being performed)
#                     in the second column
#   m_eqtl_out_dir:   path to output files (cis or trans) with eQTL output per tissue,
#                     thresholded to some reasonable level such as 0.01 or 0.05.
#                     These are assumed to follow the output format generated
#                     by Matrix eQTL i.e. with columns named SNP, gene, beta,
#                     t-stat, p-value, and FDR. The beta, t-stat, and FDR
#                     columns may contain dummy values if these are not of
#                     interest.
#   tissue_names:     vector of names for each tissue in alphanumeric order
#   level1:           target error rate for Level 1 discoveries.
#                     Default is 0.05
#   level2:           target error rate for Level 2 discoveries.
#                     Default is 0.05
#   level3:           target error rate for Level 3 discoveries.
#                     Default is 0.05
#
# Return:
# Data frame with one row for each selected SNP-gene pair.
# First column contains SNP name. Second column contains gene name.
# These are followed by one column for each tissue with a nonzero entry giving the
# p-value for significant associations or a 0 to indicate that the association in
# the given tissue was not significant
get_eSNPs_multi_tissue <- function(genes_by_tissue, snps_by_tissue,
                                   n_tests_per_SNP, m_eqtl_out_dir, tissue_names,
                                   level1 = 0.05, level2 = 0.05, level3 = 0.05) {
  # Assign standard names to columns with snp and gene names
  names(snps_by_tissue)[1] <- "snp"
  names(genes_by_tissue)[1] <- "gene"
  
  pvals_all_tissues <- get_pvals_and_fam_p(genes_by_tissue, snps_by_tissue,
                                           m_eqtl_out_dir, tissue_names)
  n_tissue <- length(tissue_names)
  
  print("Applying error control procedure")
  
  # pvals_all_tissues contains the Simes p for each SNP-gene pair in the column fam_p
  # We can treat these as equivalent to the single tissue SNP-gene pair p-values for the
  # purpose of selecting SNPs
  xT_meqtl_out <- data.frame(SNP = as.character(pvals_all_tissues$SNP),
                             gene = as.character(pvals_all_tissues$gene),
                             beta = NA, "t-stat" = NA,
                             "p-value" = pvals_all_tissues$fam_p,
                             FDR = NA)
  xT_meqtl_out <- xT_meqtl_out[order(xT_meqtl_out$p.value), ]
  names(xT_meqtl_out) <- c("SNP", "gene", "beta", "t-stat", "p-value", "FDR")
  m_eqtl_out_filename <- tempfile(tmpdir = getwd())
  write.table(xT_meqtl_out, m_eqtl_out_filename, quote = FALSE,
              row.names = FALSE)
  remove(xT_meqtl_out)
  
  eSNPs <- get_eSNPs(n_tests_per_SNP, m_eqtl_out_filename, method = "BH",
                     level1 = level1, level2 = level2)
  
  print(paste("Number of eSNPs = ", nrow(eSNPs)))
  
  # Generate txt output file with full set of SNP-gene pairs
  eAssoc_filename <- tempfile(tmpdir = getwd())
  get_eAssociations(eSNPs, n_tests_per_SNP, m_eqtl_out_filename,
                    eAssoc_filename, by_snp = TRUE)
  level2_sel <- read.table(eAssoc_filename, header = TRUE,
                           stringsAsFactors = FALSE)
  
  unlink(m_eqtl_out_filename) 
  unlink(eAssoc_filename)
  
  # Get total number of rejections R across SNP-gene pairs
  R <- nrow(level2_sel)
  
  print(paste("Number of selected SNPxgene pairs =", R))
  
  # Table for selected families i.e. SNP-gene pairs
  level2_sel$pair_names <- paste(level2_sel$SNP, "*", level2_sel$gene, sep = "")
  sel_families <- pvals_all_tissues[which(pvals_all_tissues$pair_names %in%
                                            level2_sel$pair_names), ]

  # Control FDR within selected SNPxgene pairs to adjusted target level
  n_sel_per_SNP <- table(sel_families$SNP)
  n_sel_per_SNP <- data.frame(SNP = names(n_sel_per_SNP),
                              n_sel = as.numeric(n_sel_per_SNP))
  sel_families <- merge(sel_families, n_sel_per_SNP, by = "SNP", all.x = TRUE)
  names(n_tests_per_SNP) <- c("SNP", "n_genes_per_SNP")
  sel_families <- merge(sel_families, n_tests_per_SNP, by = "SNP", all.x = TRUE)
  sel_families$q_adj <- sel_families$n_sel * nrow(eSNPs) * level3 /
    nrow(n_tests_per_SNP) / sel_families$n_genes_per_SNP
  sel_families$n_sel <- NULL
  sel_families$n_genes_per_SNP <- NULL
  
  # Check that Matrix eQTL output threshold used was okay
  max_recorded <- max(pvals_all_tissues[ , 4:(n_tissue + 3), with = FALSE],
                      na.rm = TRUE)
  if (min(sel_families$q_adj) >= max_recorded) {
    warning("Matrix eQTL output threshold may be too small for given levels")
  }
  
  # Indices for columns containing p-values
  col_ind_pvals <- which(sapply(names(sel_families), grep, fixed = TRUE,
                                pattern = "p.value") == 1)
  
  # Get column index for additional columns to be selected
  col_ind_ntests <- which(names(sel_families) == "n_tests_pair")
  col_ind_qadj <- which(names(sel_families) == "q_adj")
  
  # Get rejections within each selected family
  rej_by_fam_q <- apply(sel_families[ , c(col_ind_pvals, col_ind_ntests,
                                          col_ind_qadj), with = FALSE], 1, 
                        bh_by_fam_q_adj)
  sel_pairs <- data.frame(matrix(t(rej_by_fam_q), nrow = ncol(rej_by_fam_q)))
  return_value <- data.frame(family = sel_families$pair_names,
                             fam_p = sel_families$fam_p, 
                             as.matrix(sel_families[ , col_ind_pvals,
                                                    with = FALSE]) * sel_pairs)
  names(return_value) <- c("family", "fam_p", tissue_names)
  return_value$family <- as.character(return_value$family)
  
  # Clean up NA entries - these correspond to non-selected hypotheses
  return_value[is.na(return_value)] <- 0
  
  # Redo output columns so that first column is SNP and second column is gene
  return_value[ , 2] <- as.character(sapply(as.character(return_value$family), get_gene_name))
  return_value[ , 1] <- as.character(sapply(as.character(return_value$family), get_snp_name))
  names(return_value)[1:2] <- c("SNP", "gene")
  
  return_value
}


# Function: get_gene_name -----------------------------------------------------
# Internal helper function to get gene name back out from pair name
get_gene_name <- function(str) {
  strsplit(str, "*", fixed = TRUE)[[1]][2]
}

# Function: get_snp_name ------------------------------------------------------
# Internal helper function to get SNP name back out from pair name
get_snp_name <- function(str) {
  strsplit(str, "*", fixed = TRUE)[[1]][1]
}


# Function: get_pvals_and_fam_p -----------------------------------------------
# Internal helper function to get table with p-value for each SNP-gene pair
# in each tissue, the number of tests per pair, and the Simes p-value
# for the each SNP-gene pair across tissues
get_pvals_and_fam_p <- function(genes_by_tissue, snps_by_tissue, m_eqtl_out_dir,
                                tissue_names) {
  m_eqtl_outfiles <- list.files(m_eqtl_out_dir, full.names = TRUE)
  n_tissue <- length(m_eqtl_outfiles)
  pvals_all_tissues <- data.table()
  for (i in 1:n_tissue) {
    print(paste("Reading output for tissue ", tissue_names[i], sep = ""))
    cur_data <- read.table(m_eqtl_outfiles[i], header = TRUE,
                           stringsAsFactors = FALSE)
    cur_data_table <- data.frame(
      pair_names = paste(cur_data[ , "SNP"], "*", cur_data[ , "gene"], sep = ""),
      SNP = cur_data[ , "SNP"],
      gene = cur_data[ , "gene"],
      p.value = cur_data[ , "p.value"])
    names(cur_data_table)[4] <- paste("p.value", i, sep = "_")
    cur_data_table <- data.table(cur_data_table)
    setkey(cur_data_table, pair_names)
    
    # If there are duplicate SNP-gene pairs keep entry with smaller p-value
    if (sum(duplicated(cur_data_table)) > 0) {
      cur_data_table <- unique(cur_data_table)
      print("Warning: Duplicate key in current output")
    }
    
    if (i == 1) {
      pvals_all_tissues <- cur_data_table
    } else {
      pvals_all_tissues <- merge(pvals_all_tissues, cur_data_table,
                                 by = c("pair_names", "SNP", "gene"),
                                 all = TRUE)
    }
  }
  
  print("Calculating p-values for each SNP-gene pair")
  
  # Get number of tests for each SNP-gene pair, which corresponds to the 
  # number of tissues in which the gene and SNP were both measured
  genes_by_tissue <- data.table(genes_by_tissue)
  setkey(genes_by_tissue, gene_name)
  snps_by_tissue <- data.table(snps_by_tissue)
  setkey(snps_by_tissue, snp_name)
  pvals_all_tissues$n_tests_pair <- rowSums(
    genes_by_tissue[J(pvals_all_tissues$gene), 2:ncol(genes_by_tissue),
                    with = FALSE] +
      snps_by_tissue[J(pvals_all_tissues$SNP), 2:ncol(snps_by_tissue),
                     with = FALSE] == 2)
  
  # Get column index for this column
  col_ind_ntests <- which(names(pvals_all_tissues) == "n_tests_pair")
  
  # Find p-value for each SNP gene pair (i.e. hypothesis family)                                              
  pvals_all_tissues$fam_p <- apply(pvals_all_tissues[ , c(4:(n_tissue + 3),
                                                          col_ind_ntests),
                                                     with = FALSE],
                                   1, get_simes_p_given_n_tests)
  
  pvals_all_tissues
}


# Function: bh_by_fam_q_adj ---------------------------------------------------
# Internal helper function to apply BH procedure at given level within each
#   selected family (i.e. group of hypotheses)
# Args:
#   input:     vector containing p-values for hypotheses in family followed
#              by number of tests in family and adjusted target q as final entry
# Return:
#   Logical vector indicating which hypotheses were rejected
bh_by_fam_q_adj <- function(input) {
  # Last two entries of input vector should be number of tests and threshold
  m <- length(input)
  n_tests <- input[m-1]
  threshold <- input[m]
  
  # Entries before that are the p-values. Set NAs to 1 and compute sorted version.
  pvals_orig <- input[-c(m-1,m)]  
  pvals_orig[which(is.na(pvals_orig))] <- 1
  pvals <- sort(pvals_orig)
  
  # Get rejections using adjusted FDR target level
  inds_q <- which((as.numeric(pvals) / (1:length(pvals))) <= threshold / n_tests)
  R_q <- ifelse(length(inds_q) > 0, max(inds_q), 0)
  p_threshold <- ifelse(R_q > 0, pvals[R_q], 0)
  as.vector(pvals_orig <= p_threshold) * 1
}


# Function: get_simes_p_given_n_tests -----------------------------------------
# Internal helper function to compute Simes p-value given p-values and number of 
# tests in family
# Args:
#   input:  vector containing p-values for hypotheses in family followed
#           by number of tests in family as final entry
# Return:
#   Simes p-value
get_simes_p_given_n_tests <- function(input) {  
  # Last entry of input vector should be number of tests
  m <- length(input)
  n_tests <- input[m]
  
  # Entries before that are the p-values
  pvals <- input[-m]
  
  # Compute Simes p
  pvals <- sort(as.numeric(pvals))
  n_tests * min(pvals / seq(1:length(pvals)))
}


