# eQTL example ----------------------------------------------------------------
# Perform hierarchical error control using toy data sets from Matrix eQTL

# Setup
library(MatrixEQTL)
library(TreeQTL)
source(paste(find.package("TreeQTL"), "/demo/setup_mEQTL.R", sep = ""))

# Distance used to define nearby region
dist <- 1e6

# Generate output files from Matrix eQTL by calling helper function
# which runs Matrix eQTL example script
mEQTL_out_cis <- "mEQTL_out_cis.txt"
mEQTL_out_trans <- "mEQTL_out_trans.txt"
setup_mEQTL(mEQTL_out_cis, mEQTL_out_trans, dist)

# Read in location files from Matrix eQTL
base_dir <- find.package('MatrixEQTL')
gene_map <- read.table(paste(base_dir, "/data/geneloc.txt", sep = ""),
                       header = TRUE, stringsAsFactors = FALSE)
snp_map <- read.table(paste(base_dir, "/data/snpsloc.txt", sep = ""),
                      header = TRUE, stringsAsFactors = FALSE)

# Identify eSNPs which affect nearby genes 

# Get number of genes nearby to each SNP
n_tests_per_SNP <- get_n_tests_per_SNP(snp_map, gene_map, nearby = TRUE, dist = dist)

# Get list of eSNPs
eSNPs <- get_eSNPs(n_tests_per_SNP, "mEQTL_out_cis.txt")

# Generate txt output file with full set of eAssociations
get_eAssociations(eSNPs, n_tests_per_SNP, "mEQTL_out_cis.txt", "eAssoc_cis_by_snp.txt", by_snp = TRUE)

# Identify eGenes regulated by nearby SNPs

# Get number of SNPs nearby to each gene
n_tests_per_gene <- get_n_tests_per_gene(snp_map, gene_map, nearby = TRUE, dist = dist)

# Get list of eGenes
eGenes <- get_eGenes(n_tests_per_gene, "mEQTL_out_cis.txt")

# Generate txt output file with full set of eAssociations
get_eAssociations(eGenes, n_tests_per_gene, "mEQTL_out_cis.txt", "eAssoc_cis_by_gene.txt",
                  by_snp = FALSE)

# Identify eSNPs which regulate distant genes 

# Get number of genes distal to each SNP
n_tests_per_SNP <- get_n_tests_per_SNP(snp_map, gene_map, nearby = FALSE, dist = dist)

# Get list of eSNPs with target level 0.2
eSNPs <- get_eSNPs(n_tests_per_SNP, "mEQTL_out_trans.txt", level1 = 0.2)

# Result: no SNPs are significant at given level

# Clean up
unlink("mEQTL_out_cis.txt")
unlink("mEQTL_out_trans.txt")

# Multi-trait example ---------------------------------------------------------
# Perform hierarchical error control for multi-trait association 

# Generate input file resembling that for a multi-trait association study
# Assume 100 SNPs and 100 traits
nSNP <- 100
nTrait <- 100
SNP_names <- paste(rep("SNP"), 1:nSNP, sep = "")
trait_names <- paste(rep("Trait"), 1:nTrait, sep = "")

# Construct data frame with random p-values of SNP-trait association,
# including a few small ones
multi_trait_pvals <- data.frame(SNP = rep(SNP_names, nTrait),
                                trait = sort(rep(trait_names, nSNP)),
                                t_stat = NA,
                                beta = NA,
                                "p-value" = runif(nSNP * nTrait),
                                FDR = NA)
multi_trait_pvals$p.value[sample(nrow(multi_trait_pvals), 10)] <- runif(10) * 1e-5

# Threshold and sort appropriately
multi_trait_pvals <- multi_trait_pvals[multi_trait_pvals$p.value <= 0.1, ]
multi_trait_pvals <- multi_trait_pvals[order(multi_trait_pvals$p.value), ]

# Write to disk
names(multi_trait_pvals)[5] <- "p-value"
write.table(multi_trait_pvals, "multi_trait_pvals.txt", sep = "\t", quote = FALSE,
            row.names = FALSE)

# Number of tests per SNP is just number of traits
n_tests_per_SNP <- data.frame(family = SNP_names, n_tests = nTrait)

# Get list of eSNPs (i.e. SNPs which affect any of the traits)
eSNPs <- get_eSNPs(n_tests_per_SNP, "multi_trait_pvals.txt")

# Generate txt output file with full set of eAssociations (i.e.
# all signficant SNP-trait associations)
get_eAssociations(eSNPs, n_tests_per_SNP, "multi_trait_pvals.txt", "eAssoc_multi_trait.txt",
                  by_snp = TRUE)

# Cleanup
unlink("multi_trait_pvals.txt")
unlink("eAssoc_multi_trait.txt")




